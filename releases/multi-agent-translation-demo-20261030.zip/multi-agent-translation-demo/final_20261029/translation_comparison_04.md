# Chapter 2 Part 4 - Applying the C2 Process：原文与译稿对照

新版未进入修订，本文件中的新版本仅为初稿。

## 英文原文

APPLYING THE COMMAND AND CONTROL PROCESS
Assigning an operation to a subordinate commander and establishing an appropriate
force structure are requisites for conducting the C2 process within the CC -DC -DE

framework . The following section provides considerations for applying the C2 process to
realize distributed control.
ASSIGNING OPERATIONS AND AUTHORITIES
To distribute control, the air component commander c learly defin es and assig ns
an operation, with authority to conduct the corresponding C2 process, to a
subordinate commander . In this context, certain limitations may be imposed by the air
component commander to delineate the extent of authority delegated to a subordinate
commander. Since the C2 process is conducted for a specific operation, there may be
instances where a subordinate unit has Distributed Control for some operations while the
air component c ommander retains control of others. The vignette on page 21 provides an
example of distributing control to a subordinate echelon with a specific operation with an
associated operational area. In this case, the 7440 th Composite Wing (CW) commander
was directed to open a second front in the Gulf War and accomplish several clearly
defined tasks. The mechanism for transmitting commander’s intent and authorities to the
7440 CW was an order .
An order is a communication, written, oral, or by signal, which conveys instructions from
a superior to a subordinate. Orders that delegate authority to conduct the C2 process
should focus on the purpose of the operation rather than details of how to perform
assigned tasks. Furthermore, they should specify delegated authorities that are enduring,
temporary, or conditions -based. 9
FORCE STRUCTURE
There is no mandatory structure for realizing CC -DC -DE in operations. However,
there are established USAF organizations that facilitate C2 through the CC -DC -DE
framework. The most relevant USAF structure is the air expeditionary task force (AETF).
When established, AETFs may fill the role of a Service component command or as a
subordinate Service command, generally below the CCMD -level. AETFs are scalable,
> 9For additional information on orders, see AFDP 5 -0, Planning .

tailorable organization s with three elements: a single, clearly designated commander ,
appropriate C2 mechanisms , and tailored and fully supported forces . AETFs provide
JFC s with a task -organized and integrated package with the appropriate balance of force
sustainment, C2, and force protection .10
An air component commander may delegate an AETF commander specific operational
authorities (derived from their specified command relationship) that are sufficient to
conduct the C2 process for their assigned or attached forces. This model supports
operations within the framework of CC -DC -DE because the theater air component
commander maintains centralized command through their specified command
relationship (OPCON established by the CCDR), and the AETF operates with Distributed
Control as a sub -theater echelon. Subsequently, the tactical echelon commanders are
delegated execution authority to enable decentralized operations.
Distributed Control may be replicated across several sub -theater or “middle” echelons.
During normal operations, AETF commanders, while conducting the C2 process for their
assigned operations, continuously communicate, coordinate, and synchronize their
operations with the theater air component commander and horizontally with other AETFs.
The theater air component commander is able to reprioritize and adjust the C2 activities
of the AETFs as necessary to meet the overall CCMD mission.
In a contested, degraded, or operationally limited environment, the AETF has the
necessary authority to C2 its forces when disconnected from the theater air component
commander. By delegating sufficient operational authorities and exercising them prior to
the degraded environment, the air component can continue effective air operations. See
the following “Distributed Control Examples” for a depiction of how an AETF may conduct
the C2 process at an echelon below the theater air component level.
> 10 For additional information on AETFs, see AFDP 3 -0, Operations .

Sub -Theater Force Presentation Terminology
The USAF is actively iterating through terminology to describe levels of sub -theater
command. In the following figures, the level below the theater is referred to as the
sub -theater or “middle” echelon. Another commonly used term is the “3rd echelon.”
Rega rdless of naming convention, the intent is to describe force structure below
the CCMD level. 

Distributed Control Example 1 of 3
Distributed Control Example 2 of 3

Distributed Control Example 3 of 3

JOINT TASK FORCE PROVEN FORCE:
A Historical Example of Distributed Control
An air component commander may choose to exercise Distributed Control
through an air task force (ATF) or combat wing. As units of action advance their
C2 capabilities with empowered commanders, operations centers, and robust
staffs, they may gain the capacity to conduct the C2 process for their assigned
forces. The following example from Joint Task Force (JTF) Proven Force highlights
how a combat wing or ATF may operate with Distributed Control.
During the Gulf War of 1990 -1991, the 7440th Composite Wing
(CW) (Provisional), the combat arm of JTF Proven Force, was
staffed to support combat operations and composed of airframes
capable of strike, suppression of enemy air defenses, electronic
warfare, surveillance and reconnaissance, counterair, refueling,
and res cue. Resourced with the necessary organic capabilities, the
wing was able to launch its own strike packages without assistance

from US Air Forces Central (CENTAF).
CENTAF provided the wing a n order to open a second Iraqi front whenever
possible. The order included three broad tasks: 1) deny sanctuary to the Iraqi Air
Force by attacking Iraq’s northern air bases , 2) tie down Iraqi ground forces near
the Turkish border , and 3) attack nuclear, biological, and chemical facilities in
northern Iraq. Because some of the wing’s aircraft lacked the range to attack south
of Baghdad, the wing was assigned a large area of responsibility in northern Iraq.
However, CENTAF retained command authority over the wing’s operational plans
as well as the authority to task the wing by exception.
The wing commander, Brig Gen Downer, operated in accordance with
commander’s intent, but the method of accomplishing the three broad tasks was
left to him. The wing issued its squadrons orders and allowed mission commanders
to build strike packages. The 7440th produced its own air tasking order (ATO) and
flew 50 -60 combat sorties per day in two or three waves at General Downer’s
discretion. CENTAF occasionally tasked the wing by exception , otherwise, General
Horner empowered General Downer to effectively “f ight” with his wing.
Ultimately, the 7440 CW had the authority, capability, and capacity to conduct the
entire C2 process. Gen Downer and the 7440 CW planned, prepared, executed,
and assessed operations with distributed authority from the CENTAF commander.
JTF Proven Force represents a practical example of a decentralized operation
conducted through the mission comman d philosophy and framework.
–Derived from the Gulf War Air Power Survey and a thesis presented to the
USAF’s School of Advanced Airpower Studies by Major Michael E. Fischer


## 旧版初稿

应用指挥与控制过程

将一项作战任务分配给下级指挥官并建立适当的部队结构，是在CC-DC-DE框架内实施C2过程的前提条件。以下部分提供了应用C2过程以实现分散控制的考虑因素。

分配作战任务与权限

为分散控制，空中组成部分指挥官明确界定并向 subordinate commander（下级指挥官）分配一项作战任务，同时授予其执行相应C2过程的权限。在此背景下，空中组成部分指挥官可能施加某些限制，以划定授予下级指挥官的权限范围。由于C2过程是针对特定作战任务实施的，可能存在这样的情况：下级单位对某些作战任务拥有分散控制权，而空中组成部分指挥官保留对其他任务的控制权。第21页的案例提供了将控制权分配给下级梯队并赋予特定作战任务及相关作战区域的示例。在该案例中，7440复合联队（CW）指挥官被指示在 Gulf War（海湾战争）中开辟第二战线并完成若干明确界定的任务。向7440 CW传达指挥官意图和权限的机制是一道命令。

命令是一种通信——无论是书面、口头还是通过信号——将指令从上级传达至下级。授予执行C2过程权限的命令应侧重于作战任务的目的，而非如何执行分配任务的具体细节。此外，命令应明确所授予的权限是持久的、临时的还是基于条件的。⁹

部队结构

在作战中实现CC-DC-DE并无强制性的结构。然而，美国空军已有既定组织可通过CC-DC-DE框架促进C2。最相关的美国空军结构是空中远征特遣部队（AETF）。AETF一旦组建，可充当军种组成部分指挥部的角色，或作为下属军种指挥部，通常位于CCMD级别以下。AETF是可扩展、可定制的组织，包含三个要素：单一且明确指定的指挥官、适当的C2机制，以及经过定制并得到充分支援的部队。AETF为JFC提供任务编组和整合的套件，在部队维持、C2和部队防护之间实现适当平衡。¹⁰

空中组成部分指挥官可向AETF指挥官授予特定作战权限（源自其特定指挥关系），这些权限足以对其分配或配属的部队实施C2过程。该模式支持在CC-DC-DE框架内实施作战，因为战区空中组成部分指挥官通过其特定指挥关系（由CCDR建立的OPCON）保持集中指挥，而AETF作为战区以下梯队以分散控制方式运作。随后，战术梯队指挥官被授予执行权限以实现分散作战。

分散控制可在多个战区以下或“中间”梯队中复制。在正常作战期间，AETF指挥官在为其分配的作战任务实施C2过程时，持续与战区空中组成部分指挥官沟通、协调并同步其作战行动，并与其他AETF进行横向协调。战区空中组成部分指挥官能够根据需要重新调整优先级并调整AETF的C2活动，以满足CCMD的总体任务。

在 contested、degraded 或作战受限的环境中，AETF拥有在与战区空中组成部分指挥官断开连接时对其部队实施C2的必要权限。通过在 degraded 环境出现之前授予足够的作战权限并加以行使，空中组成部分可以继续实施有效的空中作战。有关AETF如何在战区空中组成部分级别以下梯队实施C2过程的描述，请参见以下“分散控制示例”。

> ¹⁰ 有关AETF的更多信息，请参见AFDP 3-0《作战》。

战区以下部队呈现术语

美国空军正在积极迭代术语以描述战区以下指挥级别。在以下各图中，战区以下的级别被称为战区以下或“中间”梯队。另一个常用术语是“第三梯队”。无论命名惯例如何，其意图是描述CCMD级别以下的部队结构。

分散控制示例1（共3例）
分散控制示例2（共3例）

分散控制示例3（共3例）

联合特遣部队“普罗文力量”：分散控制的历史示例

空中组成部分指挥官可选择通过空中特遣部队（ATF）或作战联队行使分散控制。随着行动单位通过赋权指挥官、作战中心和强健的参谋队伍提升其C2能力，它们可能获得为其分配部队实施C2过程的能力。以下来自联合特遣部队（JTF）“普罗文力量”的示例突出了作战联队或ATF如何以分散控制方式运作。

在1990-1991年海湾战争期间，7440复合联队（CW）（临时），即JTF“普罗文力量”的作战臂，被配备以支援作战行动，由具备打击、压制敌方防空、电子战、监视与侦察、反空、加油和救援能力的机型组成。凭借必要的建制能力，该联队能够在没有美国中央空军（CENTAF）协助的情况下发射自己的打击包。

CENTAF向该联队提供了一道命令，要求其在可能时开辟伊拉克第二战线。该命令包含三项广泛任务：1）通过攻击伊拉克北部空军基地，剥夺伊拉克空军的庇护所；2）牵制土耳其边境附近的伊拉克地面部队；3）攻击伊拉克北部的核、生物和化学设施。由于该联队部分飞机缺乏攻击巴格达以南地区的航程，该联队被分配了伊拉克北部的大片责任区域。然而，CENTAF保留了对该联队作战计划的指挥权限以及例外情况下对该联队下达任务的权限。

联队指挥官Downer准将按照指挥官意图运作，但完成三项广泛任务的方法由他自行决定。该联队向其中队下达命令，并允许任务指挥官构建打击包。7440联队自行生成空中任务指令（ATO），并在Downer将军的酌情决定下每天以两到三个波次飞行50-60架次作战出动。CENTAF偶尔以例外方式对该联队下达任务，除此之外，Horner将军赋权Downer将军有效地与其联队一起“作战”。最终，7440 CW拥有实施整个C2过程的权限、能力和容量。Downer将军和7440 CW在CENTAF指挥官授予的分散权限下计划、准备、执行与评估作战行动。JTF“普罗文力量”代表了通过任务式指挥理念和框架实施分散作战的实践示例。

——摘自《海湾战争空中力量调查》以及Michael E. Fischer少校提交给美国空军高级空中力量研究学院的论文

## 旧版修订稿（参考）

## 应用指挥与控制过程

将一项作战任务分配给下级指挥官并建立适当的部队结构，是在CC-DC-DE框架内开展C2过程的前提条件。以下部分提供了应用C2过程以实现分散控制的考虑因素。

### 分配作战任务与权限

为分散控制，空中组成部分指挥官明确界定并将一项作战任务连同开展相应C2过程的权限分配给下级指挥官。在此背景下，空中组成部分指挥官可施加某些限制，以划定授予下级指挥官的权限范围。由于C2过程是针对特定作战任务开展的，可能存在这样的情况：下级单位对某些作战任务拥有分散控制权，而空中组成部分指挥官保留对其他任务的控制权。第21页的案例提供了将控制权分配给下级梯队并赋予特定作战任务及相关作战区域的示例。在该案例中，7440复合联队（CW）指挥官受命在海湾战争中开辟第二战线并完成若干明确界定的任务。向7440 CW传达指挥官意图和权限的机制是命令。

命令是一种通信方式——书面的、口头的或通过信号传递的——将上级的指示传达给下级。授予开展C2过程权限的命令应侧重于作战目的，而非如何执行分配任务的细节。此外，命令应明确所授予的权限是持久的、临时的还是基于条件的。⁹

### 部队结构

在作战中实现CC-DC-DE并无强制性的结构。然而，美国空军已有通过CC-DC-DE框架促进C2的既定组织。最相关的美国空军结构是空中远征特遣部队（AETF）。AETF一旦组建，可充当军种组成部分指挥部的角色，或作为下级军种指挥部，通常位于作战司令部（CCMD）级别以下。AETF是可扩展、可裁剪的组织，具有三个要素：单一且明确指定的指挥官、适当的C2机制，以及经过裁剪并得到充分支援的部队。AETF为联合部队指挥官（JFC）提供任务编组和整合的套件，在部队维持、C2和部队防护方面具有适当的平衡。¹⁰

空中组成部分指挥官可向AETF指挥官授予特定的作战权限（源自其特定指挥关系），足以对其分配或配属的部队开展C2过程。该模式支持CC-DC-DE框架内的作战，因为战区空中组成部分指挥官通过其特定指挥关系（由作战司令部司令建立的作战控制（OPCON））保持集中指挥，而AETF作为战区以下梯队以分散控制方式运作。随后，战术梯队指挥官被授予执行权限以实现分散执行。

分散控制可在多个战区以下或“中间”梯队中复制。在正常作战期间，AETF指挥官在为其分配作战任务开展C2过程的同时，持续与战区空中组成部分指挥官沟通、协调并同步其作战行动，并与其他AETF进行横向协调。战区空中组成部分指挥官能够根据需要重新调整优先级并调整AETF的C2活动，以满足作战司令部的总体任务。

在争夺激烈、降级或作战受限的环境中，AETF拥有在脱离战区空中组成部分指挥官时对其部队实施C2的必要权限。通过在降级环境出现之前授予足够的作战权限并加以行使，空中组成部分能够继续实施有效的空中作战。参见以下“分散控制示例”，了解AETF如何在战区空中组成部分级别以下的梯队开展C2过程。

> ¹⁰ 关于AETF的更多信息，参见AFDP 3-0《作战》。

### 战区以下部队的术语演变

美国空军正在积极迭代术语以描述战区以下指挥层级。在以下各图中，战区以下的层级被称为战区以下或“中间”梯队。另一个常用术语是“第三梯队”。无论命名惯例如何，其意图是描述作战司令部级别以下的部队结构。

分散控制示例1（共3例）

分散控制示例2（共3例）

分散控制示例3（共3例）

### 联合特遣部队“普罗文力量”：分散控制的历史示例

空中组成部分指挥官可选择通过空中特遣部队（ATF）或作战联队行使分散控制。随着行动单位通过赋权指挥官、作战中心和强健的参谋队伍提升其C2能力，它们可能获得为其分配部队开展C2过程的能力。以下来自联合特遣部队（JTF）“普罗文力量”的示例突出了作战联队或ATF如何在分散控制下运作。

> 在1990-1991年海湾战争期间，7440复合联队（临时）（CW）——联合特遣部队“普罗文力量”的作战力量——按支援作战行动编配人员，由能够执行打击、压制敌防空、电子战、监视与侦察、防空作战、加油和救援的机型组成。凭借必要的建制能力，该联队能够在没有美国中央空军（CENTAF）协助的情况下出动自己的打击包。

CENTAF向该联队下达命令，要求其尽可能开辟伊拉克第二战线。该命令包含三项广泛任务：1）通过攻击伊拉克北部空军基地，剥夺伊拉克空军的庇护所；2）牵制土耳其边境附近的伊拉克地面部队；3）攻击伊拉克北部的核、生物和化学设施。由于该联队部分飞机缺乏攻击巴格达以南地区的航程，该联队被分配了伊拉克北部的大片责任区。然而，CENTAF保留了对该联队作战计划的指挥权限以及例外情况下向该联队下达任务的权限。

联队指挥官Downer准将按照指挥官意图运作，但完成三项广泛任务的方法由他自行决定。该联队向其各中队下达命令，并允许任务指挥官构建打击包。7440联队自行生成空中任务指令（ATO），在Downer将军的酌情决定下每天以两到三个波次出动50-60架次作战飞行。CENTAF偶尔以例外方式向该联队下达任务，除此之外，Horner将军赋权Downer将军有效地指挥其联队作战。最终，7440 CW拥有开展整个C2过程的权限、能力和容量。Downer将军和7440 CW在CENTAF指挥官授予的分散权限下计划、准备、执行与评估作战行动。

联合特遣部队“普罗文力量”是通过任务式指挥理念和框架实施分散作战的实践范例。

——摘自《海湾战争空中力量调查》及Michael E. Fischer少校提交给美国空军高级空中力量研究学院的论文

## 新版初稿

# 应用指挥与控制流程

将一项作战任务分配给下级指挥官并建立适当的力量结构，是在CC-DC-DE框架内开展C2流程的前提条件。以下部分提供将C2流程应用于实现分散控制的考虑事项。

## 分配作战任务与权限

为分散控制，航空组成部分指挥官须清晰界定一项作战任务，并将其连同开展相应C2流程的权限一并分配给下级指挥官。在此背景下，航空组成部分指挥官可施加某些限制，以划定授予下级指挥官的权限范围。由于C2流程是针对特定作战任务开展的，因此可能存在这样的情况：下级单位对某些作战任务拥有分散控制权，而航空组成部分指挥官保留对其他任务的控制权。第21页的案例提供了将控制权分配给下级梯队并赋予特定作战任务及相关作战区域的示例。在此例中，第7440复合联队（CW）指挥官受命在 Gulf War 中开辟第二战线并完成若干明确界定的任务。向第7440 CW传达指挥官意图和权限的机制是一道命令。

命令是一种通信方式（书面、口头或信号），将上级的指示传达给下级。授予开展C2流程权限的命令应侧重于作战目的，而非如何执行所分配任务的细节。此外，命令应明确所授予的权限是持久的、临时的还是基于条件的。⁹

## 力量结构

在作战中实现CC-DC-DE并无强制性的结构。然而，美国空军已有既定组织可通过CC-DC-DE框架促进C2。最相关的美国空军结构是空中远征特遣部队（AETF）。一经组建，AETF可充当军种组成部分司令部或下级军种司令部的角色，通常低于CCMD层级。AETF是可扩展、可定制的组织，包含三个要素：单一且明确指定的指挥官、适当的C2机制，以及量身定制并得到充分支援的部队。AETF为JFC提供任务编组且一体化的组合，在部队维持、C2和部队防护之间保持适当平衡。¹⁰

航空组成部分指挥官可向AETF指挥官授予特定作战权限（源自其特定指挥关系），足以对其分配或配属的部队开展C2流程。该模式支持在CC-DC-DE框架内开展作战，因为战区航空组成部分指挥官通过其特定指挥关系（由CCDR建立的OPCON）保持集中指挥，而AETF作为战区下属梯队以分散控制方式运作。随后，战术梯队指挥官被授予执行权限，以实现分散作战。

分散控制可在若干战区下属或“中间”梯队中复制。在正常作战期间，AETF指挥官在为其所分配作战任务开展C2流程的同时，持续与战区航空组成部分指挥官沟通、协调并同步其作战行动，并与其他AETF进行横向协调。战区航空组成部分指挥官能够根据需要重新排定优先级并调整AETF的C2活动，以满足CCMD的总体任务。

在受争夺、降级或作战受限的环境中，AETF拥有在脱离战区航空组成部分指挥官时对其部队实施C2的必要权限。通过在降级环境出现之前授予足够的作战权限并加以行使，航空组成部分能够继续实施有效的空中作战。参见以下“分散控制示例”，了解AETF如何在战区航空组成部分层级以下的梯队开展C2流程。

> ⁹ 关于命令的更多信息，参见AFDP 5-0《计划》。
> ¹⁰ 关于AETF的更多信息，参见AFDP 3-0《作战》。

### 战区下属力量编成术语

美国空军正在积极迭代术语，以描述战区下属指挥层级。在以下各图中，战区以下的层级被称为战区下属或“中间”梯队。另一个常用术语是“第三梯队”。无论采用何种命名惯例，其意图都是描述CCMD层级以下的力量结构。

分散控制示例 1（共3例）

分散控制示例 2（共3例）

分散控制示例 3（共3例）

## 联合特遣部队“普罗文力量”：分散控制的历史示例

航空组成部分指挥官可选择通过空中特遣部队（ATF）或战斗联队来行使分散控制。随着行动单位凭借被赋予权力的指挥官、作战中心和健全的参谋机构提升其C2能力，它们可能获得为其所分配部队开展C2流程的能力。以下来自联合特遣部队（JTF）“普罗文力量”的示例凸显了战斗联队或ATF如何以分散控制方式运作。

在1990-1991年Gulf War期间，第7440复合联队（临时）（CW）——JTF“普罗文力量”的作战臂——按支援作战行动编配人员，由具备打击、压制敌防空、电子战、监视与侦察、反空、加油和救援能力的机型组成。凭借必要的建制能力资源，该联队能够在没有美国中央空军（CENTAF）协助的情况下自行出动打击包。

CENTAF向该联队提供了一道命令，要求其在可能时开辟第二伊拉克战线。该命令包含三项宽泛任务：1）通过攻击伊拉克北部空军基地，剥夺伊拉克空军的庇护所；2）牵制土耳其边境附近的伊拉克地面部队；3）攻击伊拉克北部的核、生物和化学设施。由于该联队部分飞机缺乏攻击巴格达以南地区的航程，该联队被分配了伊拉克北部的大片责任区。然而，CENTAF保留了对该联队作战计划的指挥权，以及按例外方式向该联队下达任务的权限。

联队指挥官Downer准将按照指挥官意图行事，但完成三项宽泛任务的方法则由其自行决定。该联队向其各中队下达命令，并允许任务指挥官构建打击包。第7440联队自行制定空中任务指令（ATO），并依Downer将军的判断，以两到三个波次每天出动50-60架次作战飞行。CENTAF偶尔按例外方式向该联队下达任务，除此之外，Horner将军赋予Downer将军有效“驾驭”其联队的权力。

最终，第7440 CW拥有开展整个C2流程的权限、能力和容量。Downer将军和第7440 CW凭借CENTAF指挥官分散授予的权限，对作战进行了计划、准备、执行和评估。JTF“普罗文力量”代表了通过任务式指挥理念和框架实施分散作战的一个实际示例。

——摘自《Gulf War Air Power Survey》以及Michael E. Fischer少校提交给美国空军高级空中力量研究学院的论文

## 新版修订稿

未生成：流程在术语返修处中断。
